<?php
/**
 * Quick Dial 账户管理 API
 * 端点：https://sync.ruseo.cn/api/account.php
 *
 * POST ?action=send_reset_code   发送重置验证码 { username }  → 邮件发送6位码
 * POST ?action=reset_password    重置密码 { username, code, new_password }
 * POST ?action=bind_email        绑定邮箱 { token, email } → 直接绑定
 * POST ?action=change_password   修改密码 { token, old_password, new_password }
 * GET  ?action=profile           获取信息 { token }
 */

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Headers: Content-Type, Authorization');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(200); exit; }

require_once __DIR__ . '/config.php';

$action = $_GET['action'] ?? '';
$input = json_decode(file_get_contents('php://input'), true) ?? [];

// ====== 工具 ======
function jsonResponse($code, $msg, $data = null) {
    http_response_code($code >= 200 && $code < 300 ? $code : 200);
    echo json_encode(['code' => $code, 'msg' => $msg, 'data' => $data], JSON_UNESCAPED_UNICODE);
    exit;
}
function authUser(PDO $db): array {
    $token = $_SERVER['HTTP_AUTHORIZATION'] ?? '';
    $token = preg_replace('/^Bearer\s+/i', '', $token);
    if (!$token) jsonResponse(401, '未登录');
    $stmt = $db->prepare('SELECT id, username, email, email_verified FROM qd_users WHERE token = ?');
    $stmt->execute([$token]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$user) jsonResponse(401, 'Token 无效');
    return $user;
}
function sendMail($to, $subject, $body) {
    // 163 企业邮箱 SMTP
    $smtp = [
        'host' => 'ssl://smtphz.qiye.163.com', 'port' => 994,
        'user' => 'CounterAPI@cilacila.cn',
        'pass' => 'QqnXLmRap@96WQ8E',
    ];
    if (!$smtp['user']) return false;
    $headers = "From: Quick Dial <{$smtp['user']}>\r\nContent-Type: text/plain; charset=utf-8";
    $ctx = stream_context_create(['ssl' => ['verify_peer' => false, 'verify_peer_name' => false]]);
    $fp = @stream_socket_client("{$smtp['host']}:{$smtp['port']}", $errno, $errstr, 10, STREAM_CLIENT_CONNECT, $ctx);
    if (!$fp) return false;
    $talk = function($cmd, $expect) use ($fp) {
        fwrite($fp, $cmd);
        $resp = ''; while ($line = fgets($fp, 512)) { $resp .= $line; if (substr($line, 3, 1) === ' ') break; }
        return substr($resp, 0, 3) === $expect;
    };
    if (!$talk("EHLO quickdial\r\n", '250')) { fclose($fp); return false; }
    if (!$talk("AUTH LOGIN\r\n", '334')) { fclose($fp); return false; }
    if (!$talk(base64_encode($smtp['user']) . "\r\n", '334')) { fclose($fp); return false; }
    if (!$talk(base64_encode($smtp['pass']) . "\r\n", '235')) { fclose($fp); return false; }
    if (!$talk("MAIL FROM:<{$smtp['user']}>\r\n", '250')) { fclose($fp); return false; }
    if (!$talk("RCPT TO:<{$to}>\r\n", '250')) { fclose($fp); return false; }
    if (!$talk("DATA\r\n", '354')) { fclose($fp); return false; }
    fwrite($fp, "From: Quick Dial <{$smtp['user']}>\r\nTo: {$to}\r\nSubject: {$subject}\r\nContent-Type: text/plain; charset=utf-8\r\n\r\n{$body}\r\n.\r\n");
    $ok = $talk("QUIT\r\n", '221');
    fclose($fp);
    return $ok;
}

// ====== 获取个人信息 ======
if ($action === 'profile' && $_SERVER['REQUEST_METHOD'] === 'GET') {
    $user = authUser($db);
    $stmt = $db->prepare('SELECT plan, expire_at FROM qd_subscriptions WHERE user_id = ?');
    $stmt->execute([$user['id']]);
    $sub = $stmt->fetch(PDO::FETCH_ASSOC);
    jsonResponse(200, 'ok', [
        'username' => $user['username'],
        'email' => $user['email'],
        'email_verified' => (bool)$user['email_verified'],
        'subscription' => $sub ?: null,
    ]);
}

// ====== 绑定邮箱 ======
if ($action === 'bind_email' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $user = authUser($db);
    $email = trim($input['email'] ?? '');
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) jsonResponse(400, '邮箱格式不正确');
    $stmt = $db->prepare('UPDATE qd_users SET email = ?, email_verified = 1 WHERE id = ?');
    $stmt->execute([$email, $user['id']]);
    jsonResponse(200, '邮箱绑定成功');
}

// ====== 修改密码 ======
if ($action === 'change_password' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $user = authUser($db);
    $old = $input['old_password'] ?? '';
    $new = $input['new_password'] ?? '';
    if (strlen($new) < 6) jsonResponse(400, '新密码至少6位');
    $stmt = $db->prepare('SELECT password FROM qd_users WHERE id = ?');
    $stmt->execute([$user['id']]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!password_verify($old, $row['password'])) jsonResponse(400, '原密码错误');
    $hash = password_hash($new, PASSWORD_DEFAULT);
    $stmt = $db->prepare('UPDATE qd_users SET password = ? WHERE id = ?');
    $stmt->execute([$hash, $user['id']]);
    jsonResponse(200, '密码修改成功');
}

// ====== 发送重置验证码 ======
if ($action === 'send_reset_code' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($input['username'] ?? '');
    $stmt = $db->prepare('SELECT id, email FROM qd_users WHERE username = ?');
    $stmt->execute([$username]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$user) jsonResponse(404, '用户不存在');
    if (!$user['email']) jsonResponse(400, '该账号未绑定邮箱，无法重置密码');

    $code = str_pad(mt_rand(0, 999999), 6, '0', STR_PAD_LEFT);
    $expire = date('Y-m-d H:i:s', strtotime('+10 minutes'));
    $stmt = $db->prepare('UPDATE qd_users SET reset_code = ?, reset_expire = ? WHERE id = ?');
    $stmt->execute([$code, $expire, $user['id']]);

    $sent = sendMail($user['email'], 'Quick Dial 密码重置', "您的验证码：{$code}\n10分钟内有效。");
    jsonResponse(200, $sent ? '验证码已发送至您的邮箱' : '邮件发送失败，请联系管理员');
}

// ====== 重置密码 ======
if ($action === 'reset_password' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($input['username'] ?? '');
    $code = trim($input['code'] ?? '');
    $newPassword = trim($input['new_password'] ?? '');

    if (strlen($newPassword) < 6) jsonResponse(400, '新密码至少6位');
    $stmt = $db->prepare('SELECT id FROM qd_users WHERE username = ? AND reset_code = ? AND reset_expire > NOW()');
    $stmt->execute([$username, $code]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$user) jsonResponse(400, '验证码错误或已过期');

    $hash = password_hash($newPassword, PASSWORD_DEFAULT);
    $stmt = $db->prepare('UPDATE qd_users SET password = ?, reset_code = NULL, reset_expire = NULL WHERE id = ?');
    $stmt->execute([$hash, $user['id']]);
    jsonResponse(200, '密码重置成功，请使用新密码登录');
}

jsonResponse(400, '未知操作');
