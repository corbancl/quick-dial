-- 用户表增加邮箱和重置码字段
ALTER TABLE `qd_users`
  ADD COLUMN `email` VARCHAR(128) DEFAULT NULL AFTER `password`,
  ADD COLUMN `email_verified` TINYINT NOT NULL DEFAULT 0 AFTER `email`,
  ADD COLUMN `reset_code` VARCHAR(6) DEFAULT NULL AFTER `token`,
  ADD COLUMN `reset_expire` DATETIME DEFAULT NULL AFTER `reset_code`;
