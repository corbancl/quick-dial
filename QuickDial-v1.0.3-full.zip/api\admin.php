<?php
/**
 * Quick Dial 管理员后台
 * 首次访问自动创建 qd_admins 表和管理员账号
 */

require_once __DIR__ . '/config.php';
session_start();

// 首次部署：自动建表 + 插入管理员
$db->exec("CREATE TABLE IF NOT EXISTS qd_admins (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
$cnt = $db->query('SELECT COUNT(*) as n FROM qd_admins')->fetch(PDO::FETCH_ASSOC)['n'] ?? 0;
if ($cnt == 0) {
    $db->prepare('INSERT INTO qd_admins (username, password) VALUES (?, ?)')
       ->execute(['corban', password_hash('7832518ycx', PASSWORD_DEFAULT)]);
}

// 自动迁移：给 qd_users 加 banned 字段
try { $db->exec("ALTER TABLE qd_users ADD COLUMN banned TINYINT NOT NULL DEFAULT 0"); } catch (Exception $e) {}

$action = $_GET['_a'] ?? '';

// ====== 登录 ======
if (isset($_POST['logout'])) { session_destroy(); header('Location: ' . $_SERVER['PHP_SELF']); exit; }
$loggedIn = isset($_SESSION['qd_admin']);

if (!$loggedIn && isset($_POST['username']) && isset($_POST['password'])) {
    $stmt = $db->prepare('SELECT id, username, password FROM qd_admins WHERE username = ?');
    $stmt->execute([$_POST['username']]);
    $admin = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($admin && password_verify($_POST['password'], $admin['password'])) {
        $_SESSION['qd_admin'] = $admin['username'];
        $_SESSION['qd_admin_id'] = $admin['id'];
        $loggedIn = true;
    } else {
        $error = '账号或密码错误';
    }
}

// ====== 操作 ======
$msg = '';
if ($loggedIn && $_SERVER['REQUEST_METHOD'] === 'POST') {
    if (($input = json_decode(file_get_contents('php://input'), true)) || $_POST['action'] ?? '') {
        $act = $input['action'] ?? $_POST['action'] ?? '';
        if ($act === 'activate') {
            $uid = intval($input['user_id'] ?? $_POST['user_id'] ?? 0);
            $plan = $input['plan'] ?? $_POST['plan'] ?? 'lifetime';
            $days = ['monthly' => 30, 'yearly' => 365, 'lifetime' => null][$plan] ?? null;
            $expire = $days ? date('Y-m-d H:i:s', strtotime("+{$days} days")) : null;
            $db->prepare('INSERT INTO qd_subscriptions (user_id, plan, start_at, expire_at) VALUES (?, ?, NOW(), ?) ON DUPLICATE KEY UPDATE plan=?, expire_at=?, updated_at=NOW()')
               ->execute([$uid, $plan, $expire, $plan, $expire]);
            $msg = "用户 #{$uid} 已激活 {$plan}";
        }
        if ($act === 'reset_user_password') {
            $uid = intval($input['user_id'] ?? $_POST['user_id'] ?? 0);
            $newPwd = $input['new_password'] ?? '';
            if ($uid && strlen($newPwd) >= 6) {
                $db->prepare('UPDATE qd_users SET password = ? WHERE id = ?')
                   ->execute([password_hash($newPwd, PASSWORD_DEFAULT), $uid]);
                $msg = "用户 #{$uid} 密码已重置";
            } else $msg = '密码至少6位';
        }
        if ($act === 'ban') {
            $uid = intval($input['user_id'] ?? $_POST['user_id'] ?? 0);
            if ($uid) { $db->prepare('UPDATE qd_users SET banned = 1 WHERE id = ?')->execute([$uid]); $msg = "用户 #{$uid} 已封禁"; }
        }
        if ($act === 'unban') {
            $uid = intval($input['user_id'] ?? $_POST['user_id'] ?? 0);
            if ($uid) { $db->prepare('UPDATE qd_users SET banned = 0 WHERE id = ?')->execute([$uid]); $msg = "用户 #{$uid} 已解封"; }
        }
        if ($act === 'change_password') {
            $new = $input['new_password'] ?? '';
            if (strlen($new) >= 6) {
                $hash = password_hash($new, PASSWORD_DEFAULT);
                $db->prepare('UPDATE qd_admins SET password = ? WHERE id = ?')->execute([$hash, $_SESSION['qd_admin_id']]);
                $msg = '密码已修改';
            } else $msg = '密码至少6位';
        }
    }
}

// ====== 查询 ======
function q(PDO $db, string $sql, array $p = []): array {
    $s = $db->prepare($sql); $s->execute($p); return $s->fetchAll(PDO::FETCH_ASSOC);
}
function q1(PDO $db, string $sql, array $p = []): array {
    $s = $db->prepare($sql); $s->execute($p); return $s->fetch(PDO::FETCH_ASSOC) ?: [];
}

$stats = $users = $orders = [];
if ($loggedIn) {
    $stats = [
        'users' => q1($db, 'SELECT COUNT(*) as n FROM qd_users')['n'] ?? 0,
        'todayOrders' => q1($db, 'SELECT COUNT(*) as n, COALESCE(SUM(amount),0) as r FROM qd_orders WHERE DATE(created_at)=CURDATE() AND status=1'),
        'monthRevenue' => q1($db, 'SELECT COALESCE(SUM(amount),0) as r FROM qd_orders WHERE YEAR(created_at)=YEAR(CURDATE()) AND MONTH(created_at)=MONTH(CURDATE()) AND status=1')['r'] ?? 0,
        'proUsers' => q1($db, "SELECT COUNT(*) as n FROM qd_subscriptions WHERE expire_at IS NULL OR expire_at > NOW()")['n'] ?? 0,
    ];
    $search = $_GET['s'] ?? '';
    $page = max(1, intval($_GET['p'] ?? 1));
    $limit = 20;
    $offset = ($page - 1) * $limit;
    $where = $search ? "WHERE u.username LIKE ?" : '';
    $users = q($db, "SELECT u.id, u.username, u.email, u.email_verified, u.banned, u.created_at, s.plan, s.expire_at FROM qd_users u LEFT JOIN qd_subscriptions s ON u.id=s.user_id {$where} ORDER BY u.id DESC LIMIT {$limit} OFFSET {$offset}", $search ? ["%{$search}%"] : []);
    $userTotal = q1($db, "SELECT COUNT(*) as n FROM qd_users u {$where}", $search ? ["%{$search}%"] : [])['n'] ?? 0;
    $orders = q($db, 'SELECT o.*, u.username FROM qd_orders o LEFT JOIN qd_users u ON o.user_id=u.id ORDER BY o.id DESC LIMIT 30');
}

function e($s) { echo htmlspecialchars((string)$s, ENT_QUOTES); }
function isPro($u): bool { return $u['plan'] && $u['plan'] !== 'free' && ($u['expire_at'] === null || strtotime($u['expire_at']) > time()); }
function planName($p) { return ['monthly'=>'月度','yearly'=>'年度','lifetime'=>'终身','manual'=>'手动','free'=>'免费'][$p] ?? $p; }
function statusBadge($s) { return $s ? '<span class="badge badge-green">已支付</span>' : '<span class="badge badge-gray">待支付</span>'; }
?><!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="icon" type="image/png" href="/js.png">
<title>Quick Dial 管理后台</title>
<style>
  :root { --bg: #0a0f1a; --card: rgba(255,255,255,0.03); --border: rgba(255,255,255,0.06); --text: #e2e8f0; --text2: rgba(226,232,240,0.5); --accent: #3b82f6; --green: #22c55e; --red: #ef4444; --purple: #a855f7; }
  * { margin:0; padding:0; box-sizing:border-box; }
  body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'PingFang SC', sans-serif; background: var(--bg); color: var(--text); display: flex; min-height: 100vh; }
  /* Sidebar */
  .sidebar { width: 220px; background: rgba(255,255,255,0.02); border-right: 1px solid var(--border); padding: 24px 0; flex-shrink: 0; display: flex; flex-direction: column; }
  .sidebar-logo { padding: 0 20px 24px; font-weight: 800; font-size: 17px; color: var(--accent); border-bottom: 1px solid var(--border); margin-bottom: 8px; }
  .sidebar-logo span { font-size: 10px; display: block; color: var(--text2); font-weight: 600; letter-spacing: 1px; }
  .sidebar-nav { flex: 1; }
  .sidebar-nav a { display: flex; align-items: center; gap: 10px; padding: 10px 20px; font-size: 13px; color: var(--text2); text-decoration: none; transition: all 0.15s; }
  .sidebar-nav a:hover, .sidebar-nav a.active { color: var(--text); background: rgba(255,255,255,0.03); }
  .sidebar-nav a.active { border-right: 2px solid var(--accent); }
  .sidebar-nav .icon { font-size: 16px; width: 20px; text-align: center; }
  .sidebar-footer { padding: 16px 20px; border-top: 1px solid var(--border); }
  .sidebar-user { font-size: 12px; color: var(--text2); margin-bottom: 10px; }
  .btn-logout { display: block; width: 100%; padding: 8px 0; border-radius: 8px; font-size: 12px; font-weight: 600; cursor: pointer; border: none; background: linear-gradient(135deg, rgba(239,68,68,0.15), rgba(220,38,38,0.1)); color: var(--red); transition: all 0.2s; }
  .btn-logout:hover { background: linear-gradient(135deg, rgba(239,68,68,0.25), rgba(220,38,38,0.15)); }
  /* Main */
  .main { flex: 1; overflow-y: auto; padding: 28px 32px; }
  .page-title { font-size: 22px; font-weight: 800; margin-bottom: 4px; }
  .page-sub { font-size: 13px; color: var(--text2); margin-bottom: 28px; }
  /* Stats */
  .stats { display: grid; grid-template-columns: repeat(4, 1fr); gap: 12px; margin-bottom: 32px; }
  .stat { background: var(--card); border: 1px solid var(--border); border-radius: 14px; padding: 22px 20px; }
  .stat-label { font-size: 12px; color: var(--text2); margin-bottom: 6px; }
  .stat-value { font-size: 32px; font-weight: 800; letter-spacing: -1px; }
  .stat-sub { font-size: 12px; color: var(--text2); margin-top: 4px; }
  /* Card */
  .card { background: var(--card); border: 1px solid var(--border); border-radius: 14px; padding: 24px; margin-bottom: 20px; }
  .card-title { font-size: 15px; font-weight: 700; margin-bottom: 16px; }
  /* Table */
  .search-row { display: flex; gap: 8px; margin-bottom: 16px; }
  .search-input { flex: 1; padding: 10px 14px; background: rgba(255,255,255,0.05); border: 1px solid var(--border); border-radius: 10px; color: var(--text); font-size: 13px; outline: none; }
  .search-input:focus { border-color: var(--accent); }
  table { width: 100%; border-collapse: collapse; font-size: 13px; }
  th { text-align: left; padding: 10px 12px; color: var(--text2); font-weight: 600; border-bottom: 1px solid var(--border); font-size: 12px; }
  td { padding: 10px 12px; border-bottom: 1px solid rgba(255,255,255,0.03); }
  tr:hover td { background: rgba(255,255,255,0.02); }
  .badge { display: inline-block; padding: 3px 10px; border-radius: 8px; font-size: 11px; font-weight: 600; }
  .badge-green { background: rgba(34,197,94,0.12); color: var(--green); }
  .badge-purple { background: rgba(168,85,247,0.12); color: var(--purple); }
  .badge-blue { background: rgba(59,130,246,0.12); color: var(--accent); }
  .badge-gray { background: rgba(255,255,255,0.05); color: var(--text2); }
  .badge-red { background: rgba(239,68,68,0.1); color: var(--red); }
  .btn { display: inline-flex; align-items: center; gap: 4px; padding: 8px 14px; border-radius: 8px; font-size: 12px; font-weight: 600; cursor: pointer; border: none; text-decoration: none; transition: all 0.15s; }
  .btn-primary { background: var(--accent); color: white; }
  .btn-primary:hover { opacity: 0.9; }
  .btn-outline { background: none; border: 1px solid var(--border); color: var(--text); }
  .btn-outline:hover { background: rgba(255,255,255,0.04); }
  .btn-green { background: var(--green); color: white; }
  .btn-green:hover { opacity: 0.9; }
  .btn-xs { padding: 4px 8px; font-size: 10px; border-radius: 6px; }
  .act-group { display: flex; gap: 4px; }
  .pagination { display: flex; gap: 6px; justify-content: center; margin-top: 16px; }
  .pagination a { padding: 6px 12px; border-radius: 6px; font-size: 12px; font-weight: 600; text-decoration: none; border: 1px solid var(--border); color: var(--text2); }
  .pagination a.active { background: var(--accent); border-color: var(--accent); color: white; }
  .pagination a:hover:not(.active) { background: rgba(255,255,255,0.04); }
  .msg { background: rgba(34,197,94,0.1); color: var(--green); padding: 10px 16px; border-radius: 10px; margin-bottom: 16px; font-size: 13px; }
  .form-group { margin-bottom: 14px; }
  .form-label { font-size: 12px; font-weight: 600; margin-bottom: 4px; color: var(--text2); }
  .form-input { width: 100%; padding: 10px 14px; background: rgba(255,255,255,0.05); border: 1px solid var(--border); border-radius: 10px; color: var(--text); font-size: 13px; outline: none; }
  .form-input:focus { border-color: var(--accent); }

  /* Login */
  .login-page { display: flex; align-items: center; justify-content: center; min-height: 100vh; width: 100%; }
  .login-card { background: var(--card); border: 1px solid var(--border); border-radius: 20px; padding: 48px 36px; width: 100%; max-width: 380px; text-align: center; }
  .login-card h1 { font-size: 22px; font-weight: 800; margin-bottom: 4px; }
  .login-card .sub { font-size: 13px; color: var(--text2); margin-bottom: 28px; }
  .login-card .form-input { margin-bottom: 12px; }
  .login-card .btn-primary { width: 100%; padding: 12px; }

  @media (max-width: 768px) {
    .sidebar { width: 60px; padding: 16px 0; }
    .sidebar-logo { font-size: 0; padding: 0 0 12px; text-align: center; }
    .sidebar-logo span { display: none; }
    .sidebar-nav a { padding: 10px; justify-content: center; font-size: 0; }
    .sidebar-nav a .icon { margin: 0; }
    .sidebar-footer { display: none; }
    .main { padding: 20px 16px; }
    .stats { grid-template-columns: repeat(2, 1fr); }
  }
</style>
</head>
<body>

<?php if (!$loggedIn): ?>
<div class="login-page">
  <div class="login-card">
    <h1>Quick Dial</h1>
    <div class="sub">管理后台</div>
    <form method="post">
      <input class="form-input" name="username" placeholder="管理员账号" autofocus />
      <input class="form-input" name="password" type="password" placeholder="管理员密码" />
      <button class="btn btn-primary">登录</button>
    </form>
    <?php if (isset($error)): ?><p style="color:var(--red);font-size:13px;margin-top:12px;"><?= e($error) ?></p><?php endif; ?>
  </div>
</div>

<?php else:
$tab = $_GET['tab'] ?? 'dashboard';
?>
<div class="sidebar">
  <div class="sidebar-logo">Quick Dial<span>管理后台</span></div>
  <div class="sidebar-nav">
    <a href="?tab=dashboard" class="<?= $tab==='dashboard'?'active':'' ?>"><span class="icon">📊</span> 仪表盘</a>
    <a href="?tab=users" class="<?= $tab==='users'?'active':'' ?>"><span class="icon">👥</span> 用户管理</a>
    <a href="?tab=orders" class="<?= $tab==='orders'?'active':'' ?>"><span class="icon">💰</span> 订单记录</a>
    <a href="?tab=settings" class="<?= $tab==='settings'?'active':'' ?>"><span class="icon">⚙️</span> 设置</a>
  </div>
  <div class="sidebar-footer">
    <div class="sidebar-user">👤 <?= e($_SESSION['qd_admin']) ?></div>
    <form method="post"><button name="logout" value="1" class="btn-logout">退出登录</button></form>
  </div>
</div>
<div class="main">
  <?php if ($msg): ?><div class="msg"><?= e($msg) ?></div><?php endif; ?>

  <?php if ($tab === 'dashboard'): ?>
    <div class="page-title">仪表盘</div>
    <div class="page-sub">Quick Dial 运行概览</div>
    <div class="stats">
      <div class="stat"><div class="stat-label">注册用户</div><div class="stat-value"><?= $stats['users'] ?></div></div>
      <div class="stat"><div class="stat-label">Pro 用户</div><div class="stat-value"><?= $stats['proUsers'] ?></div></div>
      <div class="stat"><div class="stat-label">今日订单</div><div class="stat-value"><?= $stats['todayOrders']['n'] ?? 0 ?></div><div class="stat-sub">¥<?= number_format($stats['todayOrders']['r'] ?? 0, 2) ?></div></div>
      <div class="stat"><div class="stat-label">本月收入</div><div class="stat-value" style="color:var(--green)">¥<?= number_format($stats['monthRevenue'], 2) ?></div></div>
    </div>

  <?php elseif ($tab === 'users'): ?>
    <div class="page-title">用户管理</div>
    <div class="page-sub">共 <?= $userTotal ?> 位用户</div>
    <div class="card">
      <form class="search-row" method="get">
        <input type="hidden" name="tab" value="users">
        <input class="search-input" name="s" value="<?= e($search) ?>" placeholder="搜索用户名..." />
        <button class="btn btn-primary">搜索</button>
        <?php if ($search): ?><a href="?tab=users" class="btn btn-outline">清除</a><?php endif; ?>
      </form>
      <table>
        <thead><tr><th>ID</th><th>用户名</th><th>状态</th><th>邮箱</th><th>注册</th><th>订阅</th><th>到期</th><th>操作</th></tr></thead>
        <tbody>
          <?php foreach ($users as $u): ?>
          <tr>
            <td><?= $u['id'] ?></td>
            <td><?= e($u['username']) ?> <?= $u['banned'] ? '<span class="badge badge-red">封禁</span>' : '' ?></td>
            <td>
              <form method="post" onsubmit="return handleQuickAct(this)" class="act-group" style="margin-bottom:4px;">
                <input type="hidden" name="action" value="<?= $u['banned'] ? 'unban' : 'ban' ?>">
                <input type="hidden" name="user_id" value="<?= $u['id'] ?>">
                <button class="btn btn-xs <?= $u['banned'] ? 'btn-green' : 'btn-outline' ?>"><?= $u['banned'] ? '解封' : '封禁' ?></button>
              </form>
            </td>
            <td style="font-size:12px;opacity:0.5;"><?= $u['email'] ? e($u['email']).($u['email_verified']?' ✅':'') : '-' ?></td>
            <td style="font-size:12px;opacity:0.5;"><?= substr($u['created_at'] ?? '', 0, 10) ?></td>
            <td><?php if (isPro($u)): ?><span class="badge <?= $u['plan']==='lifetime'?'badge-purple':'badge-blue' ?>"><?= planName($u['plan']) ?></span><?php else: ?><span class="badge badge-gray">免费</span><?php endif; ?></td>
            <td style="font-size:11px;opacity:0.5;"><?= $u['expire_at'] ? substr($u['expire_at'],0,10) : ($u['plan']==='lifetime'?'永久':'-') ?></td>
            <td>
              <form method="post" onsubmit="return handleActivate(this)" class="act-group">
                <input type="hidden" name="action" value="activate"><input type="hidden" name="user_id" value="<?= $u['id'] ?>">
                <button name="plan" value="monthly" class="btn btn-outline btn-xs">月</button>
                <button name="plan" value="yearly" class="btn btn-outline btn-xs">年</button>
                <button name="plan" value="lifetime" class="btn btn-green btn-xs">终身</button>
                <button type="button" class="btn btn-outline btn-xs" onclick="resetPwd(<?= $u['id'] ?>)">密码</button>
              </form>
            </td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
      <?php if ($userTotal > $limit): ?>
      <div class="pagination">
        <?php for ($i = 1; $i <= ceil($userTotal / $limit); $i++): ?>
          <a href="?tab=users&p=<?= $i ?><?= $search ? '&s='.urlencode($search) : '' ?>" class="<?= $i === $page ? 'active' : '' ?>"><?= $i ?></a>
        <?php endfor; ?>
      </div>
      <?php endif; ?>
    </div>

  <?php elseif ($tab === 'orders'): ?>
    <div class="page-title">订单记录</div>
    <div class="page-sub">最近 30 笔</div>
    <div class="card">
      <table>
        <thead><tr><th>ID</th><th>订单号</th><th>用户</th><th>套餐</th><th>金额</th><th>方式</th><th>状态</th><th>时间</th></tr></thead>
        <tbody>
          <?php foreach ($orders as $o): ?>
          <tr>
            <td><?= $o['id'] ?></td>
            <td style="font-size:11px;font-family:monospace;"><?= substr($o['order_no'],-12) ?></td>
            <td><?= e($o['username'] ?? '-') ?></td>
            <td><span class="badge <?= $o['plan']==='lifetime'?'badge-purple':'badge-blue' ?>"><?= planName($o['plan']) ?></span></td>
            <td style="font-weight:600;">¥<?= number_format($o['amount'], 2) ?></td>
            <td><?= $o['pay_method'] === 'wechat' ? '💚' : ($o['pay_method'] === 'alipay' ? '💙' : e($o['pay_method'])) ?></td>
            <td><?= statusBadge($o['status']) ?></td>
            <td style="font-size:11px;opacity:0.5;"><?= substr($o['created_at'] ?? '', 0, 16) ?></td>
          </tr>
          <?php endforeach; ?>
          <?php if (empty($orders)): ?><tr><td colspan="8" style="text-align:center;opacity:0.3;padding:40px;">暂无订单</td></tr><?php endif; ?>
        </tbody>
      </table>
    </div>

  <?php elseif ($tab === 'settings'): ?>
    <div class="page-title">设置</div>
    <div class="page-sub">管理员账户</div>
    <div class="card">
      <div class="card-title">修改密码</div>
      <form onsubmit="changePwd(event)">
        <div class="form-group"><label class="form-label">新密码</label><input class="form-input" id="new-pwd" type="password" placeholder="至少6位" /></div>
        <button class="btn btn-primary">保存</button>
      </form>
    </div>
    <div class="card">
      <div class="card-title">数据库初始化</div>
      <p style="font-size:12px;opacity:0.5;margin-bottom:12px;">如果首次部署，请手动执行以下 SQL：</p>
      <pre style="background:rgba(255,255,255,0.03);padding:16px;border-radius:10px;font-size:11px;overflow-x:auto;color:var(--text2);">CREATE TABLE IF NOT EXISTS qd_admins (id INT AUTO_INCREMENT PRIMARY KEY, username VARCHAR(50) NOT NULL UNIQUE, password VARCHAR(255) NOT NULL, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP);
INSERT IGNORE INTO qd_admins (username, password) VALUES ('corban', '$2y$10$HASH_PLACEHOLDER');</pre>
    </div>

  <?php endif; ?>
</div>

<script>
function handleActivate(form) { doPost(form); return false; }
function handleQuickAct(form) { doPost(form); return false; }
function doPost(form) { const fd = new FormData(form); fetch(location.href, { method: 'POST', body: fd }).then(() => location.reload()); return false; }
function resetPwd(id) {
  const pwd = prompt('为用户 #' + id + ' 设置新密码（至少6位）：');
  if (!pwd || pwd.length < 6) { alert('密码至少6位'); return; }
  fetch(location.href, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ action: 'reset_user_password', user_id: id, new_password: pwd }) })
    .then(r => r.text()).then(() => location.reload());
}
function changePwd(e) {
  e.preventDefault();
  const pwd = document.getElementById('new-pwd').value;
  if (pwd.length < 6) { alert('密码至少6位'); return; }
  fetch(location.href, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ action: 'change_password', new_password: pwd }) })
    .then(r => r.text())
    .then(() => location.reload());
}
</script>
<?php endif; ?>
</body>
</html>
