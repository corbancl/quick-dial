-- Quick Dial 支付系统 数据库表
-- 在 sync.ruseo.cn 的 MySQL 中执行

-- 订单表
CREATE TABLE IF NOT EXISTS qd_orders (
    id INT AUTO_INCREMENT PRIMARY KEY,
    order_no VARCHAR(32) NOT NULL UNIQUE,
    user_id INT NOT NULL,
    plan VARCHAR(20) NOT NULL COMMENT 'monthly/yearly/lifetime',
    amount DECIMAL(10,2) NOT NULL,
    pay_method VARCHAR(10) NOT NULL COMMENT 'wechat/alipay',
    status TINYINT NOT NULL DEFAULT 0 COMMENT '0待支付 1已支付 2已取消',
    pay_time DATETIME DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_user (user_id),
    INDEX idx_order_no (order_no),
    INDEX idx_status (status),
    FOREIGN KEY (user_id) REFERENCES qd_users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 订阅表
CREATE TABLE IF NOT EXISTS qd_subscriptions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL UNIQUE,
    plan VARCHAR(20) NOT NULL DEFAULT 'free' COMMENT 'free/monthly/yearly/lifetime',
    start_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    expire_at DATETIME DEFAULT NULL COMMENT 'NULL = 终身',
    order_id INT DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_expire (expire_at),
    FOREIGN KEY (user_id) REFERENCES qd_users(id) ON DELETE CASCADE,
    FOREIGN KEY (order_id) REFERENCES qd_orders(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 价格配置
-- monthly: ¥9.9, yearly: ¥68, lifetime: ¥198
