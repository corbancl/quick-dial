<?php
/**
 * Quick Dial 支付 API
 * 端点：https://sync.ruseo.cn/api/pay.php
 *
 * POST ?action=create_order  创建订单 { token, plan, method }
 * GET  ?action=status        查询订阅状态 { token }
 * POST ?action=notify_wechat  微信支付回调
 * POST ?action=notify_alipay  支付宝回调
 */

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Headers: Content-Type, Authorization');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(200); exit; }

require_once __DIR__ . '/config.php';

$action = $_GET['action'] ?? '';
$method = $_SERVER['REQUEST_METHOD'];
$input = json_decode(file_get_contents('php://input'), true) ?? [];

// ====== 价格配置 ======
const PLANS = [
    'monthly'  => ['name' => '月度', 'amount' => 9.90,  'days' => 30],
    'yearly'   => ['name' => '年度', 'amount' => 68.00, 'days' => 365],
    'lifetime' => ['name' => '终身', 'amount' => 198.00, 'days' => null],
];

// ====== 微信支付配置 ======
const WX_APPID  = 'YOUR_WX_APPID';
const WX_MCHID  = 'YOUR_WX_MCHID';
const WX_KEY    = 'YOUR_WX_API_KEY';
const WX_NOTIFY = 'https://sync.ruseo.cn/api/pay.php?action=notify_wechat';

// ====== 支付宝配置 ======
const ALI_APPID      = '2019011563042146';
const ALI_NOTIFY     = 'https://sync.ruseo.cn/api/pay.php?action=notify_alipay';
const ALI_GATEWAY    = 'https://openapi.alipay.com/gateway.do';
const ALI_PRIVATE_KEY = <<<'KEY'
MIIEvAIBADANBgkqhkiG9w0BAQEFAASCBKYwggSiAgEAAoIBAQCi9fQvGq2Qx8gfLPmXFVeaN1MmrzYri+4GH0sg+BqozEh8nIHLIfQrj1XpYECFeCRA8/UvVR0ix9aVwG11yPyfEtNu1rl3NtjAnsPFH0XO553DzKHyo8PRmh9KgQD1NO3AVCR5GLCl+w/1Dh2S5JyTfBD3Cipw4PAErPA72koL6kBenawrB2YMLoEmHggulqPVItFa8esFRRjwSDtXWM/u8HoNh7fF//y1Trny2rowNwPREryZ5+6BSEO28VOj6RxI4wKXoqUXbZqxBzASVpdVK88sPWvsEXPlcoGZ7I9S2XCBDOz1vLqPrRKHQ29EdOfJz6rZ0wRSNwlIUlocjWXZAgMBAAECggEAUceukEkKG2M3GfYfF2P9f4YOM5awT7A8dlQUBuqbrmQ+aFK+jCtw9r9K9QB5wMFnKDWFsQg8w+yX0rUr+XUw2b+/3ZrinmIm6puCUZV9GfWAZfd2umbW6YQ3+dK9oVC7k85mM2NhmxpgirFXxBT4Qsd7WA6A9/7aVO5Y7SCCEnHgDOlwBtbk55RKwwTQRFONJernSRsYEvblUWNvvS4wMzmBj4hM9WFHhqpJQ4Zypl0KjSdeqRKbdpyjtPlxMSWsMmlrO1b32nKF4hUishjf/qItMecJuJbWb8U83bWFT5xg68Je+ZSZ5Ta/Q1C1ZHIBnB38U9Wn3+T39tdzTUe5UQKBgQDuB/12G7B6cInQ0eUVyyMDKNz+hq/Cn8K8OutUTjT/znBew7PggrQxUW2ebSnHccmaBqYNKVafj5Q+8js7jaABx8tsd2eZ07TzgFeIDo2PY2wRYDODjqLmuNQGuXynNm6hQAxaRauXyGI8QP3DwSSVedMfa34HImOv9L9/VFInjQKBgQCvQzWW+SwIqTtzIXPKMSuF4qhPUo4CVV+s7vTzDIy8LoduytAvvEzugMwleqf05MXIbJOPEEnJe22erf1Gd0Oy7NaAXUjtwMmscINIZ7NwLDQkGyqkLKOPA6nY27OcEgk+a6OvB19zyxP5LyWWbPCsnl9BOtW0F9JajMvuihfufQKBgCHAlktCH+MsxA4NRUuy01MmXzfkR1X0q3tfa3E36cIANuTpIT+LqRt5LW8SkaMLWofxu2gQXY0goefPF2EZcv/tocXOpK0mXPlOUJslXSNg+Lj6CDP2bNkEimQttyRKzqMk3tuKF4vdSTi8Cn/Qimx7qtlAt80xLiuMK/9VKJUdAoGAajU9bX8UOy9q8msMQzQm3tyrCF7L5ggckazBTeSGCKfdtLs9DCB9Mm9kxzWcQKC+ZqW9ig3h2TJuDKH9gU1W/j/eAS4GuuWAkXohZKhLKifvdQ3tek3+0/TxYZRKNMMNTQFn0PKT2pTvRqtWiOD9vG3A5cOkq51gATWfg6+1rvUCgYAzUkIKZofkyaBYMt0pHtCa+ynPFDKOS8FOwDfZAQwgHS4/CAhP3Wj30Ra1ylX6E4xCGgc6r0STTEeYq682/YNUYW5s3PDy33L7F6WAuSZ7JOrMpqgsDKwZkR2vE1psFDd4ddPCV3mJuluDEZ7hbRRiiq5HTAFXLLcniCBOmXF7QA==
KEY;

const ALI_PUBLIC_KEY = <<<'KEY'
MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAovX0LxqtkMfIHyz5lxVXmjdTJq82K4vuBh9LIPgaqMxIfJyByyH0K49V6WBAhXgkQPP1L1UdIsfWlcBtdcj8nxLTbta5dzbYwJ7DxR9Fzuedw8yh8qPD0ZofSoEA9TTtwFQkeRiwpfsP9Q4dkuSck3wQ9woqcODwBKzwO9pKC+pAXp2sKwdmDC6BJh4ILpaj1SLRWvHrBUUY8Eg7V1jP7vB6DYe3xf/8tU658tq6MDcD0RK8mefugUhDtvFTo+kcSOMCl6KlF22asQcwElaXVSvPLD1r7BFz5XKBmeyPUtlwgQzs9by6j60Sh0NvRHTnyc+q2dMEUjcJSFJaHI1l2QIDAQAB
KEY;

// ====== 通用工具函数 ======
function pemFormat(string $raw, string $type = 'RSA PRIVATE KEY'): string {
    $wrapped = wordwrap($raw, 64, "\n", true);
    return "-----BEGIN {$type}-----\n{$wrapped}\n-----END {$type}-----";
}

function jsonResponse($code, $msg, $data = null) {
    http_response_code($code >= 200 && $code < 300 ? $code : 200);
    echo json_encode(['code' => $code, 'msg' => $msg, 'data' => $data], JSON_UNESCAPED_UNICODE);
    exit;
}

function getToken(): ?string {
    $header = $_SERVER['HTTP_AUTHORIZATION'] ?? '';
    if (preg_match('/^Bearer\s+(.+)$/i', $header, $m)) return $m[1];
    return null;
}

function authUser(PDO $db): array {
    $token = getToken();
    if (!$token) jsonResponse(401, '未登录');
    $stmt = $db->prepare('SELECT id, username FROM qd_users WHERE token = ?');
    $stmt->execute([$token]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$user) jsonResponse(401, 'Token 无效');
    return $user;
}

function generateOrderNo(): string {
    return date('YmdHis') . substr(microtime(), 2, 6) . mt_rand(1000, 9999);
}

// ====== 查询订阅状态 ======
if ($action === 'status' && $method === 'GET') {
    $user = authUser($db);
    $stmt = $db->prepare('SELECT plan, start_at, expire_at FROM qd_subscriptions WHERE user_id = ?');
    $stmt->execute([$user['id']]);
    $sub = $stmt->fetch(PDO::FETCH_ASSOC);

    $isPro = false;
    if ($sub) {
        if ($sub['expire_at'] === null) {
            $isPro = true; // 终身
        } elseif (strtotime($sub['expire_at']) > time()) {
            $isPro = true; // 未过期
        }
    }

    jsonResponse(200, 'ok', [
        'is_pro' => $isPro,
        'plan' => $sub['plan'] ?? 'free',
        'expire_at' => $sub['expire_at'] ?? null,
    ]);
}

// ====== 激活订阅（手动激活/测试用） ======
if ($action === 'activate' && $method === 'POST') {
    $user = authUser($db);
    $plan = $input['plan'] ?? 'monthly';

    if (!isset(PLANS[$plan])) jsonResponse(400, '无效的套餐');

    $cfg = PLANS[$plan];
    $expireAt = $cfg['days'] ? date('Y-m-d H:i:s', strtotime("+{$cfg['days']} days")) : null;

    // 创建激活订单
    $orderNo = generateOrderNo();
    $stmt = $db->prepare('INSERT INTO qd_orders (order_no, user_id, plan, amount, pay_method, status, pay_time) VALUES (?, ?, ?, ?, "manual", 1, NOW())');
    $stmt->execute([$orderNo, $user['id'], $plan, $cfg['amount']]);
    $orderId = $db->lastInsertId();

    // 更新订阅
    $stmt = $db->prepare('INSERT INTO qd_subscriptions (user_id, plan, start_at, expire_at, order_id) VALUES (?, ?, NOW(), ?, ?) ON DUPLICATE KEY UPDATE plan=?, expire_at=?, order_id=?, updated_at=NOW()');
    $stmt->execute([$user['id'], $plan, $expireAt, $orderId, $plan, $expireAt, $orderId]);

    jsonResponse(200, '激活成功', ['plan' => $plan, 'expire_at' => $expireAt]);
}

// ====== 创建订单 ======
if ($action === 'create_order' && $method === 'POST') {
    $user = authUser($db);
    $plan = $input['plan'] ?? '';
    $payMethod = $input['method'] ?? '';

    if (!isset(PLANS[$plan])) jsonResponse(400, '无效的套餐');
    if (!in_array($payMethod, ['wechat', 'alipay'])) jsonResponse(400, '支付方式仅支持 wechat/alipay');

    $cfg = PLANS[$plan];
    $orderNo = generateOrderNo();

    $stmt = $db->prepare('INSERT INTO qd_orders (order_no, user_id, plan, amount, pay_method, status) VALUES (?, ?, ?, ?, ?, 0)');
    $stmt->execute([$orderNo, $user['id'], $plan, $cfg['amount'], $payMethod]);

    if ($payMethod === 'wechat') {
        // 微信 Native 支付 - 获取扫码链接
        $payData = createWechatNativeOrder($orderNo, $cfg['amount'], $cfg['name']);
    } else {
        // 支付宝扫码支付
        $payData = createAlipayOrder($orderNo, $cfg['amount'], $cfg['name']);
    }

    jsonResponse(200, '订单创建成功', [
        'order_no' => $orderNo,
        'amount' => $cfg['amount'],
        'plan' => $plan,
        'method' => $payMethod,
        'qr_code' => $payData['qr'] ?? null,
        'pay_url' => $payData['pay_url'] ?? null,
        'error' => $payData['error'] ?? null,
    ]);
}

// ====== 支付宝异步通知 ======
if ($action === 'notify_alipay' && $method === 'POST') {
    $data = $_POST;
    if (!verifyAlipaySign($data)) jsonResponse(400, '签名验证失败');

    $orderNo = $data['out_trade_no'] ?? '';
    $tradeStatus = $data['trade_status'] ?? '';

    if ($tradeStatus === 'TRADE_SUCCESS') {
        completePayment($db, $orderNo);
        echo 'success'; exit;
    }
    echo 'fail'; exit;
}

// ====== 微信支付异步通知 ======
if ($action === 'notify_wechat' && $method === 'POST') {
    $xml = file_get_contents('php://input');
    $data = xmlToArray($xml);

    // 验证签名
    $sign = $data['sign'] ?? '';
    unset($data['sign']);
    if (makeWechatSign($data) !== $sign) jsonResponse(400, '签名验证失败');

    if (($data['return_code'] ?? '') === 'SUCCESS' && ($data['result_code'] ?? '') === 'SUCCESS') {
        completePayment($db, $data['out_trade_no']);
        echo '<xml><return_code><![CDATA[SUCCESS]]></return_code><return_msg><![CDATA[OK]]></return_msg></xml>';
        exit;
    }
    echo '<xml><return_code><![CDATA[FAIL]]></return_code></xml>';
    exit;
}

// ====== 完成支付（通用） ======
function completePayment(PDO $db, string $orderNo): void {
    $stmt = $db->prepare('SELECT id, user_id, plan FROM qd_orders WHERE order_no = ? AND status = 0');
    $stmt->execute([$orderNo]);
    $order = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$order) return;

    // 更新订单状态
    $stmt = $db->prepare('UPDATE qd_orders SET status = 1, pay_time = NOW() WHERE id = ?');
    $stmt->execute([$order['id']]);

    // 更新订阅
    $cfg = PLANS[$order['plan']];
    $expireAt = $cfg['days'] ? date('Y-m-d H:i:s', strtotime("+{$cfg['days']} days")) : null;

    $stmt = $db->prepare('INSERT INTO qd_subscriptions (user_id, plan, start_at, expire_at, order_id) VALUES (?, ?, NOW(), ?, ?) ON DUPLICATE KEY UPDATE plan=?, expire_at=?, order_id=?, updated_at=NOW()');
    $stmt->execute([$order['user_id'], $order['plan'], $expireAt, $order['id'], $order['plan'], $expireAt, $order['id']]);
}

// ====== 微信 Native 支付 ======
function createWechatNativeOrder(string $orderNo, float $amount, string $desc): array {
    $params = [
        'appid' => WX_APPID,
        'mch_id' => WX_MCHID,
        'nonce_str' => bin2hex(random_bytes(16)),
        'body' => "Quick Dial Pro - {$desc}",
        'out_trade_no' => $orderNo,
        'total_fee' => intval($amount * 100), // 分
        'spbill_create_ip' => $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1',
        'notify_url' => WX_NOTIFY,
        'trade_type' => 'NATIVE',
        'product_id' => $orderNo,
    ];
    $params['sign'] = makeWechatSign($params);

    $xml = arrayToXml($params);
    $resp = httpPost('https://api.mch.weixin.qq.com/pay/unifiedorder', $xml);

    $result = xmlToArray($resp);
    if (($result['return_code'] ?? '') === 'SUCCESS' && ($result['result_code'] ?? '') === 'SUCCESS') {
        return ['qr' => $result['code_url'], 'order_no' => $orderNo];
    }
    return ['qr' => null, 'error' => $result['return_msg'] ?? $result['err_code_des'] ?? '未知错误'];
}

function makeWechatSign(array $data): string {
    ksort($data);
    $str = '';
    foreach ($data as $k => $v) {
        if ($v !== '' && $k !== 'sign') {
            $str .= "{$k}={$v}&";
        }
    }
    $str .= 'key=' . WX_KEY;
    return strtoupper(md5($str));
}

function arrayToXml(array $data): string {
    $xml = '<xml>';
    foreach ($data as $k => $v) {
        $xml .= "<{$k}><![CDATA[{$v}]]></{$k}>";
    }
    return $xml . '</xml>';
}

function xmlToArray(string $xml): array {
    $obj = simplexml_load_string($xml, 'SimpleXMLElement', LIBXML_NOCDATA);
    return json_decode(json_encode($obj), true) ?: [];
}

// ====== 支付宝扫码支付 ======
function createAlipayOrder(string $orderNo, float $amount, string $desc): array {
    if (!function_exists('openssl_sign')) {
        return ['qr' => null, 'error' => '服务器缺少 OpenSSL 扩展'];
    }

    // page_pay：签名拼 URL，新窗口打开支付宝支付页，不调网关无需任何产品签约
    $biz = [
        'out_trade_no' => $orderNo,
        'total_amount' => number_format($amount, 2, '.', ''),
        'subject' => "Quick Dial Pro - {$desc}",
        'product_code' => 'FAST_INSTANT_TRADE_PAY',
    ];

    $params = [
        'app_id' => ALI_APPID,
        'method' => 'alipay.trade.page.pay',
        'format' => 'JSON',
        'charset' => 'utf-8',
        'sign_type' => 'RSA2',
        'timestamp' => date('Y-m-d H:i:s'),
        'version' => '1.0',
        'notify_url' => ALI_NOTIFY,
        'return_url' => 'https://sync.ruseo.cn/',
        'biz_content' => json_encode($biz, JSON_UNESCAPED_UNICODE),
    ];

    $params['sign'] = makeAlipaySign($params);
    if (!$params['sign']) return ['pay_url' => null, 'error' => '签名失败'];

    return ['pay_url' => ALI_GATEWAY . '?' . httpBuildAlipayQuery($params), 'order_no' => $orderNo];
}

function makeAlipaySign(array $params): string {
    ksort($params);
    $str = '';
    foreach ($params as $k => $v) {
        if ($v !== '' && $v !== null && $k !== 'sign') {
            $str .= "{$k}={$v}&";
        }
    }
    $str = rtrim($str, '&');

    $key = openssl_get_privatekey(pemFormat(ALI_PRIVATE_KEY));
    openssl_sign($str, $sign, $key, OPENSSL_ALGO_SHA256);
    return base64_encode($sign);
}

function verifyAlipaySign(array $data): bool {
    $sign = $data['sign'] ?? '';
    $signType = $data['sign_type'] ?? 'RSA2';
    unset($data['sign'], $data['sign_type']);

    ksort($data);
    $str = '';
    foreach ($data as $k => $v) {
        if ($v !== '' && $v !== null) {
            $str .= "{$k}={$v}&";
        }
    }
    $str = rtrim($str, '&');

    $key = openssl_get_publickey(pemFormat(ALI_PUBLIC_KEY, 'PUBLIC KEY'));
    if ($signType === 'RSA2') {
        return (bool) openssl_verify($str, base64_decode($sign), $key, OPENSSL_ALGO_SHA256);
    }
    return (bool) openssl_verify($str, base64_decode($sign), $key);
}

function httpBuildAlipayQuery(array $params): string {
    $parts = [];
    foreach ($params as $k => $v) {
        $parts[] = $k . '=' . urlencode($v);
    }
    return implode('&', $parts);
}

function httpPost(string $url, string $body): string {
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => $body,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT => 15,
        CURLOPT_SSL_VERIFYPEER => false,
    ]);
    $resp = curl_exec($ch);
    curl_close($ch);
    return $resp ?: '';
}

jsonResponse(400, '未知操作: ' . $action);
