<?php
/**
 * Quick Dial 云同步 API
 * 端点：https://sync.ruseo.cn/api/sync.php
 * 
 * POST /api/sync.php?action=register  注册 { username, password }
 * POST /api/sync.php?action=login     登录 { username, password }
 * GET  /api/sync.php?action=download  下载 { token } via Header
 * POST /api/sync.php?action=upload    上传 { token, data, version } 
 */

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Headers: Content-Type, Authorization');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

// 数据库配置 - 复用现有 config
require_once __DIR__ . '/config.php';

$action = $_GET['action'] ?? '';
$method = $_SERVER['REQUEST_METHOD'];
$input = json_decode(file_get_contents('php://input'), true) ?? [];

function jsonResponse($code, $msg, $data = null) {
    http_response_code($code >= 200 && $code < 300 ? $code : 200);
    echo json_encode(['code' => $code, 'msg' => $msg, 'data' => $data], JSON_UNESCAPED_UNICODE);
    exit;
}

function getToken(): ?string {
    $header = $_SERVER['HTTP_AUTHORIZATION'] ?? '';
    if (preg_match('/^Bearer\s+(.+)$/i', $header, $m)) return $m[1];
    return null;
}

function authUser(PDO $db): array {
    $token = getToken();
    if (!$token) jsonResponse(401, '未登录');
    $stmt = $db->prepare('SELECT id, username FROM qd_users WHERE token = ?');
    $stmt->execute([$token]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$user) jsonResponse(401, 'Token 无效');
    return $user;
}

// ====== 注册 ======
if ($action === 'register' && $method === 'POST') {
    $username = trim($input['username'] ?? '');
    $password = trim($input['password'] ?? '');
    
    if (mb_strlen($username) < 2 || mb_strlen($username) > 50) {
        jsonResponse(400, '用户名 2-50 字符');
    }
    if (mb_strlen($password) < 6) {
        jsonResponse(400, '密码至少 6 位');
    }
    
    $stmt = $db->prepare('SELECT id FROM qd_users WHERE username = ?');
    $stmt->execute([$username]);
    if ($stmt->fetch()) jsonResponse(409, '用户名已存在');
    
    $token = bin2hex(random_bytes(32));
    $hash = password_hash($password, PASSWORD_BCRYPT);
    
    $stmt = $db->prepare('INSERT INTO qd_users (username, password, token) VALUES (?, ?, ?)');
    $stmt->execute([$username, $hash, $token]);
    
    jsonResponse(201, '注册成功', ['token' => $token, 'username' => $username]);
}

// ====== 登录 ======
if ($action === 'login' && $method === 'POST') {
    $username = trim($input['username'] ?? '');
    $password = trim($input['password'] ?? '');
    
    $stmt = $db->prepare('SELECT id, username, password FROM qd_users WHERE username = ?');
    $stmt->execute([$username]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$user || !password_verify($password, $user['password'])) {
        jsonResponse(401, '用户名或密码错误');
    }
    
    $token = bin2hex(random_bytes(32));
    $stmt = $db->prepare('UPDATE qd_users SET token = ? WHERE id = ?');
    $stmt->execute([$token, $user['id']]);
    
    jsonResponse(200, '登录成功', ['token' => $token, 'username' => $user['username']]);
}

// ====== 下载同步数据 ======
if ($action === 'download' && $method === 'GET') {
    $user = authUser($db);
    
    $stmt = $db->prepare('SELECT data, version, updated_at FROM qd_sync WHERE user_id = ? ORDER BY version DESC LIMIT 1');
    $stmt->execute([$user['id']]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$row) jsonResponse(404, '暂无云端数据');
    
    jsonResponse(200, 'ok', [
        'data' => json_decode($row['data'], true),
        'version' => (int)$row['version'],
        'updated_at' => $row['updated_at'],
    ]);
}

// ====== 上传同步数据 ======
if ($action === 'upload' && $method === 'POST') {
    $user = authUser($db);
    
    $data = $input['data'] ?? null;
    $version = (int)($input['version'] ?? 0);
    
    if (!$data || !is_array($data)) jsonResponse(400, '数据格式错误');
    
    $jsonData = json_encode($data, JSON_UNESCAPED_UNICODE);
    if (!$jsonData) jsonResponse(400, 'JSON 编码失败');
    
    // 检查版本号，防止旧数据覆盖新数据
    $stmt = $db->prepare('SELECT version FROM qd_sync WHERE user_id = ? ORDER BY version DESC LIMIT 1');
    $stmt->execute([$user['id']]);
    $current = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($current && $version > 0 && $version < $current['version']) {
        jsonResponse(409, '版本冲突，请先下载最新数据', ['server_version' => (int)$current['version']]);
    }
    
    $newVersion = $current ? $current['version'] + 1 : 1;
    $size = strlen($jsonData);
    
    $stmt = $db->prepare('INSERT INTO qd_sync (user_id, data, version, size_bytes) VALUES (?, ?, ?, ?)');
    $stmt->execute([$user['id'], $jsonData, $newVersion, $size]);
    
    jsonResponse(200, '同步成功', ['version' => $newVersion, 'size' => $size]);
}

jsonResponse(400, '未知操作: ' . $action);
